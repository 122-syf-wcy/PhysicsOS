/** Style example only; the public experiment SDK has not been released. */
export interface LensFrame {
  readonly objectDistanceMeters: number
  readonly imageDistanceMeters: number | null
  readonly imageKind: 'real' | 'virtual' | 'none'
}

/** Presentation state is separate from engine-owned physical facts. */
export interface LensViewState {
  readonly selectedObjectId: string | null
  readonly showRays: boolean
}
