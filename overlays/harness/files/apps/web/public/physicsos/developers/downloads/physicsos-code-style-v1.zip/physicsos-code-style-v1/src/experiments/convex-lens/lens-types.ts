/** Style example only; the SDK contract is src/contract-wire.ts. */
export interface LensFrame {
  readonly objectDistanceMeters: number
  readonly imageDistanceMeters: number | null
  readonly imageKind: 'real' | 'virtual' | 'none'
}

/** Presentation state is separate from engine-owned physical facts. */
export interface LensViewState {
  readonly selectedObjectId: string | null
  readonly showRays: boolean
}
