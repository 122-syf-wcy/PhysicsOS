# PhysicsOS 代码风格工具包 v1.0

这是辅助代码风格工具包。需要预览、构建与 ZIP 打包，请下载独立实验模板 physicsos-experiment-template-v1.zip。

## 开始

需要 Node.js >=24.7。首次安装需联网：

```sh
npm install
npm run format:write
npm run check
```

依赖版本固定；第一次安装生成 package-lock.json，请保留它。之后使用 npm ci。

check 执行 Prettier、源码文件命名、ESLint 与 TypeScript，不代替物理行为测试和浏览器验收。
将实验代码放在 src/experiments/<experiment-id>/，将 AGENTS.md 复制到该目录。
类型示例 lens-types.ts 只演示风格，不是公共平台契约。

## 贡献方式

贡献者独立制作实验文件，在对应实验页上传 ZIP，后台审核通过后自动同步。无需克隆 PhysicsOS 或修改主站源码。
本工具包只做风格检查。凸透镜已接通独立实验模板、文件上传、管理员审核与自动展示；其他实验逐步适配，不需要克隆主仓库。

## 文件

AGENTS.md：可直接交给开发助手的约束。
CODE_STYLE.md：命名、格式、类型和架构约定。
其他 Markdown：三维、物理、视觉、作者和投稿规范。
experiment.schema.json / experiment.example.json：候选格式，不代表审核通过。

来自 PhysicsOS；自有代码和文档遵循 Apache-2.0。第三方依赖各自遵循其许可证。
