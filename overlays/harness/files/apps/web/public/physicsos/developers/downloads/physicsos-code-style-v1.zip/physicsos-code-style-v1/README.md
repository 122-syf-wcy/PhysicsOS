# PhysicsOS 代码风格工具包 v1.0

这是代码一致性工具包，不是已经发布的实验 SDK。没有完整实验页面、引擎、打包或上传功能。

## 开始

需要 Node.js >=24.7。首次安装需联网：

```sh
npm install
npm run format:write
npm run check
```

依赖版本固定；第一次安装生成 package-lock.json，请保留它。之后使用 npm ci。

check 执行 Prettier、源码文件命名、ESLint 与 TypeScript，不代替物理行为测试和浏览器验收。
将实验代码放在 src/experiments/<experiment-id>/，将 AGENTS.md 复制到该目录。
类型示例 lens-types.ts 只演示风格，不是公共平台契约。

## 在已有 PhysicsOS 仓库中

不要覆盖项目现有配置。遵循根 AGENTS.md、CONTRIBUTING.md 与所在目录的工具规则。
Web 源码修改 overlays/harness/files 后在 Harness 环境验证；当前贡献路径为 GitHub PR。
包格式、公开 SDK、ZIP 上传审核尚在建设，不能把本工具包当作已接通的投稿客户端。

## 文件

AGENTS.md：可直接交给开发助手的约束。
CODE_STYLE.md：命名、格式、类型和架构约定。
其他 Markdown：三维、物理、视觉、作者和投稿规范。
experiment.schema.json / experiment.example.json：候选格式，不代表审核通过。

来自 PhysicsOS；自有代码和文档遵循 Apache-2.0。第三方依赖各自遵循其许可证。
